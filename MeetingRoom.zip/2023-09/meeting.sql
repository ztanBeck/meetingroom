/*
 Navicat Premium Data Transfer

 Source Server         : localhost本地
 Source Server Type    : MySQL
 Source Server Version : 80022
 Source Host           : localhost:3306
 Source Schema         : meeting

 Target Server Type    : MySQL
 Target Server Version : 80022
 File Encoding         : 65001

 Date: 07/09/2023 21:51:50
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for application_record
-- ----------------------------
DROP TABLE IF EXISTS `application_record`;
CREATE TABLE `application_record`  (
  `application_id` int(0) NOT NULL AUTO_INCREMENT,
  `dept_id` int(0) NOT NULL,
  `room_id` int(0) NOT NULL,
  `user_id` int(0) NULL DEFAULT NULL,
  `apply_time` datetime(0) NOT NULL,
  `audit_time` datetime(0) NULL DEFAULT NULL,
  `audit_status` int(0) NOT NULL DEFAULT 0,
  `reject_reason` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `apply_date` date NOT NULL,
  `apply_slot` int(0) NOT NULL,
  `meeting_theme` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `meeting_size` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`application_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2138001309 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of application_record
-- ----------------------------
INSERT INTO `application_record` VALUES (1589559, 2, 5, 23087363, '2023-09-07 18:09:51', '2023-09-07 18:09:51', 1, '', '2023-09-07', 7, '1005', 60);
INSERT INTO `application_record` VALUES (2248663, 1, 1, 1734887643, '2023-09-07 20:58:37', '2023-09-07 20:58:37', 1, '', '2023-09-07', 2, '123456', 60);
INSERT INTO `application_record` VALUES (17711679, 1, 5, 1, '2023-09-07 18:08:37', '2023-09-07 18:08:38', 1, '', '2023-09-07', 2, '123', 60);
INSERT INTO `application_record` VALUES (66014578, 2, 4, 23087363, '2023-09-07 18:12:07', '2023-09-07 18:12:07', 1, '', '2023-09-07', 1, '1005', 30);
INSERT INTO `application_record` VALUES (155009826, 1, 1, 1734887643, '2023-09-07 20:58:37', '2023-09-07 20:58:37', 1, '', '2023-09-07', 4, '123456', 60);
INSERT INTO `application_record` VALUES (171918691, 1, 1, 1734887643, '2023-09-07 20:58:37', '2023-09-07 20:58:37', 1, '', '2023-09-07', 1, '123456', 60);
INSERT INTO `application_record` VALUES (218779511, 2, 4, 23087363, '2023-09-07 18:28:45', '2023-09-07 18:28:45', 1, '', '2023-09-07', 7, '1005', 30);
INSERT INTO `application_record` VALUES (284970985, 2, 1, 23087363, '2023-09-07 20:59:17', '2023-09-07 20:59:17', 1, '', '2023-09-07', 11, '1005', 60);
INSERT INTO `application_record` VALUES (296633022, 2, 1, 23087363, '2023-09-07 20:59:17', '2023-09-07 20:59:17', 1, '', '2023-09-07', 9, '1005', 60);
INSERT INTO `application_record` VALUES (422199821, 2, 1, 23087363, '2023-09-07 20:59:17', '2023-09-07 20:59:17', 1, '', '2023-09-07', 10, '1005', 60);
INSERT INTO `application_record` VALUES (536627873, 2, 5, 23087363, '2023-09-07 18:09:51', '2023-09-07 18:09:51', 1, '', '2023-09-07', 4, '1005', 60);
INSERT INTO `application_record` VALUES (558710965, 2, 5, 23087363, '2023-09-07 18:11:28', '2023-09-07 18:11:28', 1, '', '2023-09-07', 3, '1005', 60);
INSERT INTO `application_record` VALUES (573457032, 1, 1, 1734887643, '2023-09-07 20:58:37', '2023-09-07 20:58:37', 1, '', '2023-09-07', 5, '123456', 60);
INSERT INTO `application_record` VALUES (644566937, 2, 5, 23087363, '2023-09-07 18:11:28', '2023-09-07 18:11:28', 1, '', '2023-09-07', 8, '1005', 60);
INSERT INTO `application_record` VALUES (985679967, 2, 4, 23087363, '2023-09-07 18:28:45', '2023-09-07 18:28:45', 1, '', '2023-09-07', 4, '1005', 30);
INSERT INTO `application_record` VALUES (1145782856, 1, 1, 1734887643, '2023-09-07 20:58:37', '2023-09-07 20:58:37', 1, '', '2023-09-07', 3, '123456', 60);
INSERT INTO `application_record` VALUES (1214795288, 1, 3, 1, '2023-09-07 18:31:21', '2023-09-07 18:31:21', 1, '', '2023-09-07', 7, '123', 30);
INSERT INTO `application_record` VALUES (1300056066, 1, 4, 1, '2023-09-07 18:28:29', '2023-09-07 18:28:29', 1, '', '2023-09-07', 5, '123', 30);
INSERT INTO `application_record` VALUES (1304444952, 2, 5, 23087363, '2023-09-07 18:09:51', '2023-09-07 18:09:51', 1, '', '2023-09-07', 5, '1005', 60);
INSERT INTO `application_record` VALUES (1384136710, 1, 5, 1, '2023-09-07 18:08:38', '2023-09-07 18:08:40', 1, '', '2023-09-07', 12, '123', 60);
INSERT INTO `application_record` VALUES (1407729765, 2, 4, 23087363, '2023-09-07 18:12:07', '2023-09-07 18:12:07', 1, '', '2023-09-07', 2, '1005', 30);
INSERT INTO `application_record` VALUES (1518882164, 2, 4, 23087363, '2023-09-07 18:28:45', '2023-09-07 18:28:45', 1, '', '2023-09-07', 6, '1005', 30);
INSERT INTO `application_record` VALUES (1577731422, 2, 4, 23087363, '2023-09-07 18:12:07', '2023-09-07 18:12:07', 1, '', '2023-09-07', 3, '1005', 30);
INSERT INTO `application_record` VALUES (1700744095, 1, 5, 1, '2023-09-07 18:08:26', '2023-09-07 18:08:37', 1, '', '2023-09-07', 1, '123', 60);
INSERT INTO `application_record` VALUES (1805404250, 2, 5, 23087363, '2023-09-07 18:09:51', '2023-09-07 18:09:51', 1, '', '2023-09-07', 6, '1005', 60);

-- ----------------------------
-- Table structure for department
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department`  (
  `dept_id` int(0) NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `dept_phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `dept_no` varchar(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `dept_password` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`dept_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES (1, '开发部', '13451678901', '1001', '232323');
INSERT INTO `department` VALUES (2, '策划部', '13467299832', '1002', '454545');
INSERT INTO `department` VALUES (3, '美术部', '15643529438', '1003', '787878');
INSERT INTO `department` VALUES (4, '宣传部', '15634238374', '1004', '121212');

-- ----------------------------
-- Table structure for manager
-- ----------------------------
DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager`  (
  `username` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`username`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of manager
-- ----------------------------
INSERT INTO `manager` VALUES ('admin', 'admin');

-- ----------------------------
-- Table structure for meeting_record
-- ----------------------------
DROP TABLE IF EXISTS `meeting_record`;
CREATE TABLE `meeting_record`  (
  `record_id` int(0) NOT NULL AUTO_INCREMENT,
  `meeting_theme` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `meeting_size` int(0) NOT NULL,
  `dept_id` int(0) NOT NULL,
  `room_id` int(0) NOT NULL,
  `meeting_date` date NOT NULL,
  `meeting_slot` int(0) NOT NULL,
  `apply_id` int(0) NOT NULL,
  PRIMARY KEY (`record_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 98 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of meeting_record
-- ----------------------------
INSERT INTO `meeting_record` VALUES (98, '123', 60, 1, 5, '2023-09-07', 1, 1700744095);
INSERT INTO `meeting_record` VALUES (99, '123', 60, 1, 5, '2023-09-07', 2, 17711679);
INSERT INTO `meeting_record` VALUES (100, '123', 60, 1, 5, '2023-09-07', 12, 1384136710);
INSERT INTO `meeting_record` VALUES (101, '1005', 60, 2, 5, '2023-09-07', 4, 536627873);
INSERT INTO `meeting_record` VALUES (102, '1005', 60, 2, 5, '2023-09-07', 5, 1304444952);
INSERT INTO `meeting_record` VALUES (103, '1005', 60, 2, 5, '2023-09-07', 6, 1805404250);
INSERT INTO `meeting_record` VALUES (104, '1005', 60, 2, 5, '2023-09-07', 7, 1589559);
INSERT INTO `meeting_record` VALUES (105, '1005', 60, 2, 5, '2023-09-07', 3, 558710965);
INSERT INTO `meeting_record` VALUES (106, '1005', 60, 2, 5, '2023-09-07', 8, 644566937);
INSERT INTO `meeting_record` VALUES (107, '1005', 30, 2, 4, '2023-09-07', 1, 66014578);
INSERT INTO `meeting_record` VALUES (108, '1005', 30, 2, 4, '2023-09-07', 2, 1407729765);
INSERT INTO `meeting_record` VALUES (109, '1005', 30, 2, 4, '2023-09-07', 3, 1577731422);
INSERT INTO `meeting_record` VALUES (110, '123', 30, 1, 4, '2023-09-07', 5, 1300056066);
INSERT INTO `meeting_record` VALUES (111, '1005', 30, 2, 4, '2023-09-07', 4, 985679967);
INSERT INTO `meeting_record` VALUES (112, '1005', 30, 2, 4, '2023-09-07', 6, 1518882164);
INSERT INTO `meeting_record` VALUES (113, '1005', 30, 2, 4, '2023-09-07', 7, 218779511);
INSERT INTO `meeting_record` VALUES (114, '123', 30, 1, 3, '2023-09-07', 7, 1214795288);
INSERT INTO `meeting_record` VALUES (115, '123456', 60, 1, 1, '2023-09-07', 1, 171918691);
INSERT INTO `meeting_record` VALUES (116, '123456', 60, 1, 1, '2023-09-07', 2, 2248663);
INSERT INTO `meeting_record` VALUES (117, '123456', 60, 1, 1, '2023-09-07', 3, 1145782856);
INSERT INTO `meeting_record` VALUES (118, '123456', 60, 1, 1, '2023-09-07', 4, 155009826);
INSERT INTO `meeting_record` VALUES (119, '123456', 60, 1, 1, '2023-09-07', 5, 573457032);
INSERT INTO `meeting_record` VALUES (120, '1005', 60, 2, 1, '2023-09-07', 9, 296633022);
INSERT INTO `meeting_record` VALUES (121, '1005', 60, 2, 1, '2023-09-07', 10, 422199821);
INSERT INTO `meeting_record` VALUES (122, '1005', 60, 2, 1, '2023-09-07', 11, 284970985);

-- ----------------------------
-- Table structure for meeting_room
-- ----------------------------
DROP TABLE IF EXISTS `meeting_room`;
CREATE TABLE `meeting_room`  (
  `room_id` int(0) NOT NULL AUTO_INCREMENT,
  `room_no` varchar(3) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `room_size` int(0) NOT NULL,
  `room_status` tinyint(1) NOT NULL DEFAULT 1,
  `air` tinyint(1) NOT NULL DEFAULT 1,
  `projector` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`room_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of meeting_room
-- ----------------------------
INSERT INTO `meeting_room` VALUES (1, '301', 60, 1, 1, 1);
INSERT INTO `meeting_room` VALUES (2, '302', 30, 0, 1, 1);
INSERT INTO `meeting_room` VALUES (3, '303', 30, 1, 0, 1);
INSERT INTO `meeting_room` VALUES (4, '304', 30, 1, 1, 1);
INSERT INTO `meeting_room` VALUES (5, '305', 60, 1, 1, 0);
INSERT INTO `meeting_room` VALUES (6, '306', 60, 1, 1, 1);
INSERT INTO `meeting_room` VALUES (7, '401', 30, 1, 1, 1);
INSERT INTO `meeting_room` VALUES (8, '402', 30, 1, 1, 1);
INSERT INTO `meeting_room` VALUES (10, '307', 60, 1, 1, 1);

-- ----------------------------
-- Table structure for status
-- ----------------------------
DROP TABLE IF EXISTS `status`;
CREATE TABLE `status`  (
  `room_id` int(0) NOT NULL AUTO_INCREMENT,
  `room_no` varchar(4) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `one` tinyint(1) NULL DEFAULT 1,
  `two` tinyint(1) NULL DEFAULT 1,
  `three` tinyint(1) NULL DEFAULT 1,
  `four` tinyint(1) NULL DEFAULT 1,
  `five` tinyint(1) NULL DEFAULT 1,
  `six` tinyint(1) NULL DEFAULT NULL,
  `seven` tinyint(1) NULL DEFAULT NULL,
  `eight` tinyint(1) NULL DEFAULT NULL,
  `nine` tinyint(1) NULL DEFAULT NULL,
  `ten` tinyint(1) NULL DEFAULT NULL,
  `eleven` tinyint(1) NULL DEFAULT NULL,
  `twelve` tinyint(1) NULL DEFAULT NULL,
  `room_size` int(0) NULL DEFAULT NULL,
  `air` tinyint(1) NULL DEFAULT 1,
  `projector` tinyint(1) NULL DEFAULT 1,
  PRIMARY KEY (`room_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of status
-- ----------------------------
INSERT INTO `status` VALUES (1, '301', 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 60, 1, 1);
INSERT INTO `status` VALUES (2, '302', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 1, 1);
INSERT INTO `status` VALUES (3, '303', 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 30, 0, 1);
INSERT INTO `status` VALUES (4, '304', 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 30, 1, 1);
INSERT INTO `status` VALUES (5, '305', 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 60, 1, 0);
INSERT INTO `status` VALUES (6, '306', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 60, 1, 1);
INSERT INTO `status` VALUES (7, '401', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 30, 1, 1);
INSERT INTO `status` VALUES (8, '402', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 30, 1, 1);
INSERT INTO `status` VALUES (10, '307', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 60, 1, 1);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `user_id` int(0) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `dept_id` int(0) NULL DEFAULT NULL,
  `dept_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `status` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`, `no`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '张三', '18315012340', '1001', '111111', '1001@qq.com', 1, '开发部', 1);
INSERT INTO `user` VALUES (23087363, '阿萨达1', '19923535771', '10051', '1111111', '222@qq.com', 2, '策划部', 1);
INSERT INTO `user` VALUES (1228293916, '云长', '18315012345', 'T1010', '111111', '11@qq.com', 1, '开发部', 1);
INSERT INTO `user` VALUES (1560954603, '李四', '18315012345', '1010', '101010', '123@qq.com', 2, '策划部', 1);
INSERT INTO `user` VALUES (1734887643, '航海王1', '18315013781', 'q1010', '123456', '111@qq.com', 1, '开发部', 1);
INSERT INTO `user` VALUES (1812873482, '周瑜', '19923535879', '1009', '1009', '999@qq.com', 1, '开发部', 1);
INSERT INTO `user` VALUES (1851803127, '刘备', '18150134567', '1110', '1110', '11@qq.com', 2, '策划部', 1);
INSERT INTO `user` VALUES (1875201057, '曹操', '18315013254', '1006', '123456', '1006@qq.com', 1, '开发部', 1);

SET FOREIGN_KEY_CHECKS = 1;
